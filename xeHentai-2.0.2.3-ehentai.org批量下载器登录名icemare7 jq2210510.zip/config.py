# coding:utf-8
# --UTF8补丁-- #

# 检查并自动下载更新
auto_update = "download"

# 后台模式
daemon = False

# 删除任务时同时删除下载的文件
delete_task_files = False

# 设置下载目录
dir = "."

# 是否下载原始图片（如果存在），需要登录
download_ori = False

# 设置下载的图片范围, 格式为 开始位置-结束位置, 或者单张图片的位置,  
# 使用逗号来分隔多个范围, 例如 5-10,15,20-25, 默认为下载所有
download_range = None

# 下载线程数
download_thread_cnt = 5

# 设置下载图片的超时
download_timeout = 10

# 忽略配额判断，继续下载
ignored_errors = []

# 使用日语标题, 如果关闭则使用英文或罗马字标题
jpn_title = True

# 保存日志的路径
log_path = "eh.log"

# 设置日志装逼等级
log_verbose = 2

# 设置最低下载速度，低于此值将换源重新下载
low_speed_threshold = 10

# 下载完成后生成zip压缩包并删除下载目录
make_archive = False

# 设置代理, 可以指定多次, 当前支持的类型: socks5/4a, http(s), glype. 代理默认只用于扫描网页
proxy = []

# 同时使用代理来下载图片和扫描网页
proxy_image = True

# 仅使用代理来下载图片, 不用于扫描网页
proxy_image_only = False

# 将图片重命名为原始名称，如果关闭则使用序号
rename_ori = False

# 设置JSON-RPC监听IP
rpc_interface = "localhost"

# RPC服务端启动后自动打开浏览器页面
rpc_open_browser = True

# 设置JSON-RPC监听端口
rpc_port = None

# 设置JSON-RPC密钥
rpc_secret = None

# 是否保存任务到h.json，可用于断点续传
save_tasks = False

# 扫描线程数
scan_thread_cnt = 1

# 是否更新到测试分支
update_beta_channel = False

